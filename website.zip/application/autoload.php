<? 

    session_start();

	require('nanite/Nanite.php');
	require('controllers/controller.php');
	require('routes.php');