<div class="jumbotron text-center header-welcome">
    <div class="container">

      <h1 class="display-4"><i class="fa fa-graduation-cap" aria-hidden="true"></i> KTK Assistant</h1>
      <p class="lead">- ваш личный помошник в учебе.</p>

      <div class="row">

          <div class="col-md-5 offset-md-1 mb-1">
              <a class="btn btn-secondary btn-lg btn-block" href="/plane" role="button"><i class="fa fa-paper-plane-o" aria-hidden="true"></i> Расписание</a>
          </div>
          <div class="col-md-5 mb-1">
            <a class="btn btn-secondary btn-lg btn-block" href="/homework" role="button"><i class="fa fa-briefcase" aria-hidden="true"></i> Домашнее задание</a>
          </div>

      </div>


    </div>
</div>

<div class="container">
    
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item active" aria-current="page"><i class="fa fa-newspaper-o" aria-hidden="true"></i> Новости</li>
      </ol>
    </nav>
    
    <div class="mb-3">
        
        <div id="news"><div class="text-center text-secondary p-3">Загрузка новостей...</div></div>
        <div id="pagination"></div>
        <script>news();</script>
        
    </div>
    
</div>