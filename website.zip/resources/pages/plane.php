<div class="container mt-3">
    <nav aria-label="breadcrumb"><ol class="breadcrumb"><li class="breadcrumb-item active" aria-current="page"><i class="fa fa-paper-plane-o" aria-hidden="true"></i> Расписание</li></ol></nav>
    <div id="seccession"><div class="text-center text-secondary p-3">Загрузка отделений...</div></div>
    <div id="group"></div><div id="content"></div>
    <script>if($.cookie('default')) { var default_cookie = $.cookie('default');$('#loading').show(); $('#seccession').html('<a onclick="update()" class="btn btn-block btn-outline-secondary mb-3" href="#update">Сменить группу</a>');$.get('/api/plane?group=' + default_cookie, function(data){ $('#loading').hide();$('#content').html(data); });} else { $('#loading').show(); $.get("/api/plane", function(data){ $('#loading').hide();$('#seccession').html(data); });} </script>
</div>
