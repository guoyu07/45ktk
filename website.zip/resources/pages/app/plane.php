
<div class="row mb-3">
	<div class="col"><a href="/app/main" class="btn btn-outline-secondary btn-block">Назад</a></div>
	<div class="col"><a href="/app/plane/update/" class="btn btn-primary btn-block">Обновить расписание группы</a></div>
</div>

<div id="no-find"></div>

<div class="row">



<?

    $days = array('Понедельник','Вторник','Среда','Четверг','Пятница', 'Суббота');
    foreach ($days as $day) plane($day);
    
    function plane($day) {
        
        $mysqli = database::connect();
        $seccession = $_SESSION["seccession"];
        $ggroup = $_SESSION["ggroup"];
        $hwork = $mysqli->query("SELECT * FROM `plane` WHERE seccession = '$seccession' and ggroup = '$ggroup' and day = '$day'");
        if(mysqli_num_rows($hwork) == null) {
            print('<script>$("#no-find").html("Обновите расписание");</script>');
        } 
        else {

            print('<div class="col-md-4"><div class="card mb-3"><div class="card-header"> '.$day.' </div><div class="card-body">');

            while ($result = mysqli_fetch_array($hwork)) {
                    print('<div class="p-2 rounded mb-1" style="border: 1px solid rgba(0,0,0,.125);">
                    <div class="row">
                        <div class="col">'.$result["predmet"].'</div>
                        <div class="col-md-3 text-center"><a style="color:blue;cursor:pointer" onclick="edit('.$result["id"].')"><i class="fa fa-pencil" aria-hidden="true"></i></a></div>
                    </div>
                </div>');
            }
            
            print('</div></div></div>');
        }
            
            database::close($mysqli); 
    }
?>


<script type="text/javascript">
    
    function edit(value) {

        if(predmet = prompt('Изменить предмет', '..')) {

            $('#loading').show();

            $.get('/app/plane/edit?predmet=' + predmet + '&value=' + value, function(data) {

                var ss = JSON.parse(data);

                $('#loading').hide();

                alert('Изменено!.');

                location.reload();


            });


        } 

    }

</script>



</div>
