
<div class="row mb-3">
	<div class="col"><a href="/app/main" class="btn btn-outline-secondary btn-block">Назад</a></div>
	<div class="col"><a href="/app/homework/add" class="btn btn-primary btn-block">Добавить домашнюю работу</a></div>
</div>



<?

            $mysqli = database::connect();

            $seccession = $_SESSION["seccession"];
            $ggroup = $_SESSION["ggroup"];

            $hwork = $mysqli->query("SELECT * FROM `homework` WHERE seccession = '$seccession' and ggroup = '$ggroup' ORDER BY id DESC");

            if(mysqli_num_rows($hwork) == null) {
                print('<div class="text-center"><h5>Не найдено</h5></div>');
            } 
            else {

                print('<div class="bg-white box-shadow p-3"><div class="table-responsive-md"><table class="table table-striped table-bordered"><thead><tr><th scope="col">Предмет</th><th scope="col">ДЗ</th><th scope="col">Управление</th></tr></thead><tbody>');

                while ($result = mysqli_fetch_array($hwork)) {
                    print('<tr><td>'.$result["predmet"].'</td><td>'.$result["text"].'</td><td><a href="/app/homework/remove/'.$result["id"].'">Удалить</a><br /><a href="/app/homework/update/'.$result["id"].'">Редактировать</a></td></tr>');
                }

                print('</tbody></table></div></div>');

            }

            database::close($mysqli); 


?>