
<div class="row mb-3">
	<div class="col"><a href="/app/homework" class="btn btn-outline-secondary btn-block">Назад</a></div>
</div>


<div class="box-shadow bg-white p-4">

  <?php

    $id = $content[2];
    $mysqli = database::connect();
    $sql = $mysqli->query("SELECT * FROM `homework` WHERE id = '".$id."'");
    $result = mysqli_fetch_array($sql);
    database::close($mysqli); 

?>

<form action="/app/homework/update" method="post">
  <input type="hidden" name="id" value="<?=$result["id"];?>">
  <div class="form-group">
    <label>Предмет.</label>
    <input type="text" class="form-control" name="predmet" value="<?=$result["predmet"];?>">
  </div>
  <div class="form-group">
    <label>Содержимое</label>
    <textarea class="form-control" rows="3" name="text"><?=$result["text"];?></textarea>
  </div>
  <div class="form-group">
      <button type="submit" class="btn btn-block btn-primary">Обновить</button>
  </div>
</form>

</div>