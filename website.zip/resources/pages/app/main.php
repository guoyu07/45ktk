<?php 

	if(!AppController::checkUser($_SESSION["login"], $_SESSION["password"])) {
			echo 'Авторизрван. '.$_SESSION["role"].$_SESSION["seccession"];
	}


?>

<div class="row">

<? if($_SESSION["role"] == 'admin') { ?>

    <div class="col-md-6 mb-3">
        
        <div class="card box-shadow border-0">
          <div class="card-body">
            <h5 class="card-title">Управление старостами</h5>
            <p class="card-text">Удаление и добавление старосты.</p>
            <a href="/app/praepostor" class="btn btn-block btn-secondary">Перейти</a>
          </div>
        </div>
    
    </div>
    
    <div class="col-md-6 mb-3">
        
        <div class="card border-0 box-shadow">
          <div class="card-body">
            <h5 class="card-title">Новости</h5>
            <p class="card-text">Управление новостями.</p>
            <a href="/app/news" class="btn btn-block btn-secondary">Перейти</a>
          </div>
        </div>
    
    </div>
    
    <div class="col-md-6 mb-3">
        
        <div class="card box-shadow border-0">
          <div class="card-body">
            <h5 class="card-title">Удалить расписание</h5>
            <p class="card-text">Старосты могут сами обновлять свою группу</p>
            <a href="/app/plane/delete" class="btn btn-block btn-secondary">Перейти</a>
          </div>
        </div>
    
    </div>
    
    <div class="col-md-6">
        
        <div class="card box-shadow border-0">
          <div class="card-body">
            <h5 class="card-title">Ежегодное обновление</h5>
            <p class="card-text">Процедура обновления всех групп и удаления всех старост. Процедура необходима, чтобы не обновлять отдельно группы старост и добавлять группы каждый год.</p>
            <a href="/app/all/update" class="btn btn-block btn-secondary">Начать</a>
          </div>
        </div>
    
    </div>

<? } else { ?>	
    
    <div class="col-md-6">
        <div class="card border-0 box-shadow">
          <div class="card-body">
            <h5 class="card-title">Домашняя работа</h5>
            <p class="card-text">Создание, редактирование и удаление.</p>
            <a href="/app/homework" class="btn btn-block btn-secondary">Перейти</a>
          </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card border-0 box-shadow">
          <div class="card-body">
            <h5 class="card-title">Расписание</h5>
            <p class="card-text">Обновление и редактирование.</p>
            <a href="/app/plane" class="btn btn-block btn-secondary">Перейти</a>
          </div>
        </div>
    </div>
<? } ?>	

</div>