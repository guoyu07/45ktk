<div class="container mt-3">
    
   <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item active" aria-current="page">
            <i class="fa fa-sign-in" aria-hidden="true"></i> Авторизация 
        </li>
      </ol>
   </nav>  
    

    
    <? if(isset($_SESSION["error_auth"])) {print('<div class="alert alert-danger" role="alert">Ошибка авторизации.</div>'); unset($_SESSION["error_auth"]); }?>	
    
    
     <form action="/app/auth" method="post">
      <div class="form-group">
          <div class="input-group mb-2">
            <div class="input-group-prepend">
              <div class="input-group-text"><i class="fa fa-user" aria-hidden="true"></i></div>
            </div>
            <input type="text" class="form-control" name="login" placeholder="Логин.">
          </div>
      </div>
      <div class="form-group">
        <div class="input-group mb-2">
            <div class="input-group-prepend">
              <div class="input-group-text"><i class="fa fa-key" aria-hidden="true"></i></div>
            </div>
            <input type="password" class="form-control" name="password" placeholder="Пароль.">
        </div>
      </div>
      <button type="submit" class="btn btn-secondary"><i class="fa fa-sign-in" aria-hidden="true"></i> Авторизоваться</button>
    </form>   
    
    
</div>