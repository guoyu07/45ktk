
<div class="row mb-3">
	<div class="col"><a href="/app/praepostor" class="btn btn-outline-secondary btn-block">Назад</a></div>
</div>

<form action="/app/praepostor/add" method="post">
	
    <div id="seccession"></div>
    <div id="group"></div>
    <div id="content">Загрузка...</div>
    
    <hr/>
    
	<div class="form-group">
	    <div class='input-group'>
            <div class='input-group-prepend'><div class='input-group-text'>Логин</div></div>
            <input type="text" class="form-control" name="login" placeholder="Придумайте логин">
        </div>
	</div>
	<div class="form-group">
        <div class='input-group'>
            <div class='input-group-prepend'><div class='input-group-text'>Пароль</div></div>
	       <input type="password" class="form-control" name="password" placeholder="Придумайте пароль">
        </div>
	</div>

  <button type="submit" class="btn btn-primary btn-block">Добавить аккаунт</button>
</form>

<script>
    $.get('/api/praepostor', function(data){ 
        $('#seccession').html(data); 
        $('#content').html(''); 
    });
</script>