
<div class="row mb-3">
	<div class="col"><a href="/app/main" class="btn btn-outline-secondary btn-block">Назад</a></div>
	<div class="col"><a href="/app/praepostor/add" class="btn btn-primary btn-block">Добавить аккаунт</a></div>
</div>


<?

            $mysqli = database::connect();

            $sql = $mysqli->query("SELECT * FROM `users` WHERE role = 'praepostor'");
            if(mysqli_num_rows($sql) == null) {
                print('<div class="text-center"><h5>Аккаунты не найдены</h5></div>');
            } 
            else {

                print('<div class="bg-white box-shadow p-3"><div class="table-responsive-md"><table class="table table-striped table-bordered"><thead><tr><th scope="col">Логин</th><th scope="col">Отделение</th><th scope="col">Группа</th><th scope="col">Управление</th></tr></thead><tbody>');

                while ($result = mysqli_fetch_array($sql)) {
                    print('<tr><td>'.$result["login"].'</td><td>'.$result["seccession"].'</td><td>'.$result["ggroup"].'</td><td><a href="/app/praepostor/remove/'.$result["id"].'">Удалить аккаунт</a></td></tr>');
                }

                print('</tbody></table></div></div>');

            }

            database::close($mysqli); 


?>