
<div class="row mb-3">
	<div class="col"><a href="/app/main" class="btn btn-outline-secondary btn-block">Назад</a></div>
	<div class="col"><a href="/app/news/add" class="btn btn-primary btn-block">Добавить новость</a></div>
</div>

<div id="praepostor"></div>

<div id="pagination"></div>


<script>
	
    $('#loading').show();

    $.get('/api/news', function(data){

      var ss = JSON.parse(data);

        $('#loading').hide();

        $('#pagination').pagination({
            dataSource: ss,
            pageSize: 40,
            callback: function(data, pagination) {
                var html = nesss(data);
                $("#praepostor").html(html);
            }
        });

    });


      function nesss(data) {

	      var html = '<div class="bg-white box-shadow p-3 mb-3"><div class="table-responsive-md"><table class="table"><thead><tr><th scope="col">Название новости</th><th scope="col">Содержимое</th><th scope="col">Управление</th></tr></thead><tbody>';

	      $.each(data, function(index, item) { 
              
	        html += '<tr>'; 
              if(item.id != "undefined") {
                html += '<th scope="row"> ' + item.title + ' </th><td>' + item.news + '</td><td><a href="/app/news/remove/'+ item.id +'">Удалить</a><br /><a href="/app/news/update/'+ item.id +'">Редактировать</a></td>';
              } else {
                  html += '<td>Новости не найдены</td>';
              }
	        html += '</tr>';

	      });

	      html += '</tbody></table></div></div>';


	      return html;
	  };





</script>