
<div class="row mb-3">
	<div class="col"><a href="/app/news" class="btn btn-outline-secondary btn-block">Назад</a></div>
</div>


<div class="box-shadow bg-white p-4">
    <form action="/app/news/add" method="post">
  <div class="form-group">
    <label>Название новости.</label>
    <input type="text" class="form-control" name="title" placeholder="...">
  </div>
  <div class="form-group">
    <label>Содержимое</label>
    <textarea class="form-control" rows="3" name="text" placeholder="..."></textarea>
  </div>
  <div class="form-group">
      <button type="submit" class="btn btn-block btn-primary">Добавить</button>
  </div>
</form>
</div>