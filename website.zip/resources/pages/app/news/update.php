
<div class="row mb-3">
	<div class="col"><a href="/app/news" class="btn btn-outline-secondary btn-block">Назад</a></div>
</div>

<?php
    $id = $content[2];

    $mysqli = database::connect();
    $sql = $mysqli->query("SELECT * FROM `news` WHERE id = '".$id."'");
    $result = mysqli_fetch_array($sql);
    database::close($mysqli); 
?>

<div class="box-shadow bg-white p-4">
    <form action="/app/news/update" method="post">
      <input type="hidden" name="id" value="<?=$result["id"];?>">
  <div class="form-group">
    <label>Название новости.</label>
    <input type="text" class="form-control" name="title" value="<?=$result["title"];?>">
  </div>
  <div class="form-group">
    <label>Содержимое</label>
    <textarea class="form-control" rows="3" name="text"><?=$result["text"];?></textarea>
  </div>
  <div class="form-group">
      <button type="submit" class="btn btn-block btn-primary">Обновить</button>
  </div>
</form>
</div>