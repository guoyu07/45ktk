<!doctype html>
<html lang="ru">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      
    <title>KTK Assistant - ваш личный помошник в учебе! (Расписание, Домашнее задание)</title>
    <meta name="description" content="KTK Assistant - ваш личный помошник в учебе. Сделано в качестве проекта для сайта KTK-45.ru.">
    <meta name="author" content="Автор: Кузяев П.А.">
    <meta name="documentation" content="Документация: Водеников Р.">
      
    <link rel="shortcut icon" href="/assets/images/fav.ico" type="image/x-icon">
      
    <!-- Stylesheet -->
    <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="/assets/css/font-awesome.min.css">  
      
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="/assets/js/cookie.js"></script>  
    <script src="/assets/js/index.js"></script> 
      
  </head>
  <body class="bg-light">
      
    <div id="loading" class="center box-shadow" style="display: none;"><div class="loader-5 center"><span></span></div></div>
      
    <nav class="navbar navbar-expand-lg navbar-light bg-white">
        <div class="container">
          <a class="navbar-brand" href="/welcome">
              <i class="fa fa-graduation-cap" aria-hidden="true"></i>
              KTK Assistant
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
              <li class="nav-item">
                <a class="nav-link" href="/plane"><i class="fa fa-paper-plane-o" aria-hidden="true"></i> Расписание</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/homework"><i class="fa fa-briefcase" aria-hidden="true"></i> Домашнее задание</a>
              </li>
                
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="fa fa-eercast" aria-hidden="true"></i> Другое
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="#aboutModal" data-toggle="modal" data-target="#aboutModal">О проекте</a>
                </div>
              </li>  
                
            </ul>
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="/app"><i class="fa fa-sign-in" aria-hidden="true"></i> Авторизация</a>
              </li>
            </ul>  
          </div>
      </div>       
    </nav>


        <?php require(__DIR__ . '/../'.$empty); ?>
      
      
 
      
      <!-- Modals -->
      
      <div class="modal fade" id="aboutModal" tabindex="-1" role="dialog" aria-labelledby="aboutModalLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="aboutModalLabel">О Проекте</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                Каждый веб-разработчик знает, что такое текст-«рыба». Текст этот, несмотря на название, не имеет никакого отношения к обитателям водоемов. Используется он веб-дизайнерами для вставки на интернет-страницы и демонстрации внешнего вида контента, просмотра шрифтов, абзацев, отступов и т.д. Так как цель применения такого текста исключительно демонстрационная, то и смысловую нагрузку ему нести совсем необязательно. Более того, нечитабельность текста сыграет на руку при оценке качества восприятия макета.
              </div>
            </div>
          </div>
        </div>
      
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="/assets/js/bootstrap.min.js"></script>
  </body>
</html>     