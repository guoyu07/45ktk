<!doctype html>
<html lang="ru">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      
    <title>KTK Assistant - ваш личный помошник в учебе! (Расписание, Домашнее задание)</title>
    <meta name="description" content="KTK Assistant - ваш личный помошник в учебе. Сделано в качестве проекта для сайта KTK-45.ru.">
    <meta name="author" content="Автор: Кузяев П.А.">
    <meta name="documentation" content="Документация: Водеников Р.">
      
    <link rel="shortcut icon" href="/assets/images/fav.ico" type="image/x-icon">
      
    <!-- Stylesheet -->
    <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="/assets/css/font-awesome.min.css">  
      
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="/assets/js/cookie.js"></script>  
    <script src="/assets/js/index.js"></script> 
      
  </head>
  <body class="bg-light">
      
    <div id="loading" class="center box-shadow" style="display: none;"><div class="loader-5 center"><span></span></div></div>

      
      
    <nav class="navbar navbar-expand-lg navbar-light bg-white box-shadow">
            <div class="container">
              <a class="navbar-brand" href="/app/main">
                  <i class="fa fa-graduation-cap" aria-hidden="true"></i>
                  App Panel
              </a>
              <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>

              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                  <? if($_SESSION["role"] == 'admin') { ?>  
                  <li class="nav-item">
                    <a class="nav-link" href="/app/praepostor"><i class="fa fa-paper-plane-o" aria-hidden="true"></i> Старосты</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="/app/news"><i class="fa fa-briefcase" aria-hidden="true"></i> Новости </a>
                  </li>
                  <? } else { ?>    

                    <li class="nav-item">
                        <a class="nav-link" href="/app/homework"><i class="fa fa-paper-plane-o" aria-hidden="true"></i> Домашняя работа</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/app/plane"><i class="fa fa-briefcase" aria-hidden="true"></i> Расписание </a>
                    </li>

                  <? } ?> 

                </ul>
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <? print(htmlspecialchars($_SESSION["login"])); ?>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="/app/logout">Выход</a>
                        </div>
                    </li>
                </ul>  
              </div>
          </div>       
    </nav>
      
  <div class="container p-3 mb-4"><? require(__DIR__ . '/../'.$empty); ?></div>

      
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="/assets/js/bootstrap.min.js"></script>
  </body>
</html>   